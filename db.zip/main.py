from flask import Flask, url_for, request, render_template
from data import db_session
from data.users import User

app = Flask(__name__)
app.config['SECRET_KEY'] = 'hello'


def main():
    db_session.global_init("db/mars_explorer.db")
    session = db_session.create_session()
    user = User()
    user.surname = "Scott"
    user.name = "Ridley"
    user.age = 21
    user.position = "capitan"
    user.speciality = "research engineer"
    user.address = "module_1"
    user.email = "scott_chief@mars.org"
    user.hashed_password = "cap"
    user.set_password(user.hashed_password)
    session.add(user)

    user.surname = "Scot"
    user.name = "Ridle"
    user.age = 2
    user.position = "manager"
    user.speciality = "research engine"
    user.address = "module_2"
    user.email = "scott_chif@mars.org"
    user.hashed_password = "ca"
    user.set_password(user.hashed_password)
    session.add(user)

    user.surname = "Sco"
    user.name = "Ridl"
    user.age = 0
    user.position = "BOSS"
    user.speciality = "research en"
    user.address = "module_3"
    user.email = "sco@mars.org"
    user.hashed_password = "c"
    user.set_password(user.hashed_password)
    session.add(user)

    session.commit()

if __name__ == '__main__':
    main()
